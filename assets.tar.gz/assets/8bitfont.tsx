<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.0" name="8bitfont" tilewidth="8" tileheight="8" tilecount="144" columns="12">
 <image source="8bitfont.png" width="96" height="96"/>
</tileset>
